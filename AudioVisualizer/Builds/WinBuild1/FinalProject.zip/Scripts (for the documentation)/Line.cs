﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


//A class representing a line between two Vertices
public class Line 
{
	public Vertex v1;
	public Vertex v2;
	public LineRenderer lr;
    public Vector3 outVector;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
